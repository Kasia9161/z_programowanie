from pathlib import Path
from people_detector import PeopleDetector
import argparse

def configureArgs(parser: argparse.ArgumentParser):
	parser.add_argument("-i", "--input", required=False, default="input/", type=str, help="Relative path to directory with images to process.")
	parser.add_argument("-o", "--output", required=False, default="output/", type=str, help="Relative path to directory where processed images will be placed.")
	# argparse.BooleanOptionalAction for --debug without specifying --debug=True
	parser.add_argument("--debug", required=False, default=False, type=bool, action=argparse.BooleanOptionalAction, help="Designates whether print debug messages.")

	return parser.parse_args()

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description="Script which detects people on given images.",
		formatter_class=argparse.ArgumentDefaultsHelpFormatter)

	args = configureArgs(parser)

	try:
		open('output/output.txt', 'w').close()
		pd = PeopleDetector(Path(args.input), Path(args.output), args.debug)
		pd.process()
	except Exception as e:
		print(e)
