from .app import PeopleDetector
