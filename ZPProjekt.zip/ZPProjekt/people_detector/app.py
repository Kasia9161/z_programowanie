from pathlib import Path
from multiprocessing import Pool
import cv2
import logging


class PeopleDetector:
    MAX_THREADS_COUNT: int = 6

    LOGGER_COLOR_GRAY = "\x1b[38;5;39m"
    LOGGER_COLOR_RESET = "\x1b[0m"
    logging.basicConfig(level="INFO")

    def __init__(self, input_images_dir: Path, output_images_dir: Path, debug):
        self.__configure_logging(debug)

        self.__input_images_dir: Path = input_images_dir
        self.__output_images_dir: Path = output_images_dir

        if not (self.__input_images_dir.exists() and self.__output_images_dir.exists()):
            raise Exception("Input or output path doesn't exist !")

        self.__images_to_process = list()

    def __configure_logging(self, debug):
        level = logging.DEBUG if debug else logging.INFO
        logging.basicConfig(format='%(levelname)s: %(message)s', level=level)

    def __load_images_to_process(self):
        for f in self.__input_images_dir.iterdir():
            if f.is_file():
                self.__images_to_process.append(f.name)
                logging.debug(f"[+] Loaded image: {f.name}")

    '''
    This function is executed in multiple threads.
    '''
    def _detect_and_save_results(self, image_name: str):
        logging.debug(f"[+] Processing image: {image_name}")

        hog = cv2.HOGDescriptor()
        hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

        input_path = str(self.__input_images_dir / image_name)
        output_path = str(self.__output_images_dir / image_name)

        img = cv2.imread(input_path)

        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

        boxes, weights = hog.detectMultiScale(img_gray, winStride=(8, 8), padding=(16, 16), scale=1.03)

        if not len(boxes):
            logging.warn(f"[-] Empty image: {image_name}")
            return

        people_found = 0

        for i, (x,y,w,h) in enumerate(boxes):
            if weights[i] > 0.4:
                cv2.rectangle(img, (x, y), (x+w, y+h), (255,0,0), 2)
                people_found += 1


        logging.info(f"{PeopleDetector.LOGGER_COLOR_GRAY}[+] Image: {image_name}, found people: {people_found}{PeopleDetector.LOGGER_COLOR_RESET}")

        f = open("output/output.txt", "a")
        f.write(f"[+] Image: {image_name}, found people: {people_found} \n")
        f.close()

        cv2.imwrite(output_path, img)

    '''
    Core method. Detect people on given images and save results.
    '''
    def process(self):
        self.__load_images_to_process()

        with Pool(PeopleDetector.MAX_THREADS_COUNT) as pool:
            pool.map(self._detect_and_save_results, self.__images_to_process)

